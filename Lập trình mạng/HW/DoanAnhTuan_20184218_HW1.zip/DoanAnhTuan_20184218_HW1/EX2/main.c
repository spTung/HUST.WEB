#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

struct _node {
    char ID[10];
    char subname[20];
    char lastname[20];
    float mid;
    float final;
    char score;
    struct _node *next;
};

typedef struct _node* node;

typedef struct {
    char subjectID[10];
    char subject[20];
    int F_mid;
    int F_final;
    char semester[10];
    node students;
} data;

// Thêm điểm của 1 môn học (tạo file môn học_học kỳ) => Đọc file điểm vào cây

node createNode(char*, char*, char*, float, float, char);
node initLL();
node addNode(node, char*, char*, char*, float, float, char);
node searchNode(node root, char ID[10]);
void removeNode(node root, node p);
void freeLL(node);
void showLL(node);
int lenLL(node);

data readfile(char subjectID[10], char semester[10]); // Đọc từ file
void savefile(data); // Viết vào file
void createScoreBoard(); // Tạo file bảng điểm
void addScore();
void removeScore();
void searchScore();
void report(); // Tạo file báo cáo

int main() {
    int select;
    char next;
    do {
        printf("Learning Management System\n");
        printf("-------------------------------------\n");
        printf("1. Add a new score board\n");
        printf("2. Add score\n");
        printf("3. Remove score\n");
        printf("4. Search score\n");
        printf("5. Display score board and score report\n");
        printf("Your choice (1-5, other to quit): "); scanf("%d", &select);
        switch (select) {
            case 1: createScoreBoard(); break;
            case 2: addScore(); break;
            case 3: removeScore(); break;
            case 4: searchScore(); break;
            case 5: report(); break;
            default: return 0;
        }
        printf("Continue ? (y/n): "); fflush(stdin); scanf("%c", &next);
    } while (next != 'y' || next != 'Y');

}

node createNode(char ID[10], char subname[20], char lastname[20], float mid, float final, char score) {
    node temp;
    temp = (node)malloc(sizeof(struct _node));
    strcpy(temp->ID, ID);
    strcpy(temp->subname, subname);
    strcpy(temp->lastname, lastname);
    temp->mid = mid;
    temp->final = final;
    temp->score = score;
    temp->next = NULL;
    return temp;
}

node initLL() {
    return createNode("", "", "", 0.0, 0.0, '\0');
}

node addNode(node root, char ID[10], char subname[20], char lastname[20], float mid, float final, char score) {
    node temp = createNode(ID, subname, lastname, mid, final, score);
    temp->next = root->next;
    root->next = temp;
}

void freeLL(node root) {
    if (root == NULL) return;

    node temp;
    while (root != NULL) {
        temp = root;
        root = root->next;
        free(temp);
    }
}

void showLL(node root) {
    if (root == NULL) return;

    node p = root->next;
    while (p != NULL) {
        printf("S|%-10s|%-20s|%-20s|%-20.1f|%-20.1f|%c\n", p->ID, p->subname, p->lastname, p->mid, p->final, p->score);
        p = p->next;
    }
}

int lenLL(node root) {
    if (root == NULL) return 0;

    node p = root->next;
    int count = 0;
    while (p != NULL) {
        count++;
        p = p->next;
    }
    return count;
}

void removeNode(node root, node p) {
    if (root == NULL || p == NULL) return;

    node temp;
    while (root->next != NULL) {
        if (root->next == p) {
            temp = root->next;
            root->next = root->next->next;
            free(temp);
            break;
        }
        root = root->next;
    }
}

node searchNode(node root, char ID[10]) {
    if (root == NULL) return NULL;

    node p = root->next;
    while (p != NULL) {
        if (strcmp(p->ID, ID) == 0)
            return p;
        p = p->next;
    }
    return NULL;
}

/* ---------------------------------------------------------- */
char *trimString(char *str)
{
    char *end;

    while(isspace((unsigned char)*str)) str++;

    if(*str == 0)
        return str;

    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end)) end--;

    end[1] = '\0';

    return str;
}

data readfile(char subjectID[10], char semester[10]) {
    data d;
    char filename[30], temp[100], *t;
    FILE *f;
    int n_students;
    char ID[10], subname[20], lastname[20], score;
    float mid, final;

    d.students = initLL();
    strcpy(d.subjectID, subjectID);
    strcpy(d.semester, semester);

    sprintf(filename, "%s_%s.txt", subjectID, semester);
    f = fopen(filename, "r");

    fgets(temp, 100, f);  // SubjectID (Skip)
    fgets(temp, 100, f); t = strtok(temp, "|"); t = strtok(NULL, "|"); strcpy(d.subject, trimString(t)); // SubjectName
    fgets(temp, 100, f); t = strtok(temp, "|"); t = strtok(NULL, "|"); d.F_mid = atoi(t); // Mid Term 
                                                t = strtok(NULL, "|"); d.F_final = atoi(t); // Final Term
    fgets(temp, 100, f);  // Semester (Skip)
    
    /* Students */
    fscanf(f, "StudentCount|%d\n", &n_students); // StudentCount
    for (int i = 0; i < n_students; ++i) {
        fgets(temp, 100, f); t = strtok(temp, "|");
        t = strtok(NULL, "|"); strcpy(ID, trimString(t));
        t = strtok(NULL, "|"); strcpy(subname, trimString(t));
        t = strtok(NULL, "|"); strcpy(lastname, trimString(t));
        t = strtok(NULL, "|"); mid = atof(t);
        t = strtok(NULL, "|"); final = atof(t);
        t = strtok(NULL, "|"); score = t[1];
        addNode(d.students, ID, subname, lastname, mid, final, score);
    }
    fclose(f);
    return d;
}
/* ---------------------------------------------------------- */

void savefile(data d) {
    FILE *f;
    char filename[30];
    node p;

    sprintf(filename,"%s_%s.txt", d.subjectID, d.semester);
    f = fopen(filename, "w");
    fprintf(f, "SubjectID|%s\n", d.subjectID);
    fprintf(f, "Subject|%s\n", d.subject);
    fprintf(f, "F|%d|%d\n", d.F_mid, d.F_final);
    fprintf(f, "Semester|%s\n", d.semester);
    fprintf(f, "StudentCount|%d\n", lenLL(d.students));

    p = d.students->next;
    while (p != NULL) {
        fprintf(f, "S | %s | %s | %s | %.1f | %.1f | %c |\n", p->ID, p->subname, p->lastname, p->mid, p->final, p->score);
        p = p->next;
    }

    freeLL(d.students);
    fclose(f);
}

/** ---------------------------------------------------------- **/
float avg_score(float t1, int h1, float t2, int h2) {
    return t1 * h1 * 0.01 + t2 * h2 * 0.01;
}

void report() {
    char subjectID[10], semester[10];
    data d;
    int scores[6]; // A.0, B.1, C.2, D.3, F.5
    node min, max, p;
    float sum, avg;

    printf("Subject ID: "); fflush(stdin); scanf("%s", subjectID);
    printf("Semester: "); fflush(stdin); scanf("%s", semester);
    d = readfile(subjectID, semester);

    min = d.students->next;
    max = d.students->next;
    p = d.students->next;
    sum = 0.0;
    for (int i = 0; i < 6; ++i) scores[i] = 0;

    while (p != NULL) {
        scores[p->score - 65]++;
        avg = avg_score(p->mid, d.F_mid, p->final, d.F_final);
        sum = sum + avg;
        if (avg < avg_score(min->mid, d.F_mid, min->final, d.F_final))
            min = p;
        else if (avg > avg_score(max->mid, d.F_mid, max->final, d.F_final))
            max = p;
        p = p->next;
    }

    char filename[30];
    sprintf(filename,"%s_%s_rp.txt", subjectID, semester);
    FILE *f = fopen(filename, "w");
    fprintf(f, "The student with the highest mark is: %s %s\n", max->subname, max->lastname);
    fprintf(f, "The student with the lowest mark is: %s %s\n", min->subname, min->lastname);
    fprintf(f, "The average mark is: %.2f\n\n", sum / lenLL(d.students));
    fprintf(f, "A histogram of the subject %s is:\n", d.subject);
    for (int i = 0; i < 6; ++i) {
        if (i == 4) continue;
        fprintf(f, "%c: ", i + 65);
        for (int j = 0; j < scores[i]; ++j) fprintf(f, "*");
        fprintf(f, "\n");
    }
    freeLL(d.students);
    fclose(f);
}

/** ---------------------------------------------------------- **/

void searchScore() {
    char subjectID[10], semester[10], ID[10];
    printf("Subject ID: "); fflush(stdin); scanf("%s", subjectID);
    printf("Semester: "); fflush(stdin); scanf("%s", semester);
    printf("Student ID: "); fflush(stdin); scanf("%s", ID);

    data d = readfile(subjectID, semester);
    node n = searchNode(d.students, ID);
    if (n) {
        printf("Student: %s %s\n", n->subname, n->lastname);
        printf("Mid term: %.1f\nFinal term: %.1f\nScore: %c\n", n->mid, n->final, n->score);
    }
    else
        printf("Not Found\n");
    
    freeLL(d.students);
}

/*** ---------------------------------------------------------- ***/
char convert_score(float score) {
    if (score >= 8.5)
        return 'A';
    else if (score <= 8.4 && score > 7.0)
        return 'B';
    else if (score <= 6.9 && score >= 5.5)
        return 'C';
    else if (score <= 5.4 && score >= 4.0)
        return 'D';
    else
        return 'F';
}

void addScore() {
    char subjectID[10], semester[10], ID[10], subname[20], lastname[20];
    float mid, final;
    printf("Subject ID: "); fflush(stdin); gets(subjectID);
    printf("Semester: "); fflush(stdin); gets(semester);
    printf("Student ID: "); fflush(stdin); gets(ID);
    printf("Subname: "); fflush(stdin); gets(subname);
    printf("Lastname: "); fflush(stdin); gets(lastname);
    printf("Mid term: "); fflush(stdin); scanf("%f", &mid);
    printf("Final term: "); fflush(stdin); scanf("%f", &final);

    data d = readfile(subjectID, semester);
    addNode(d.students, ID, subname, lastname, mid, final, convert_score(mid * d.F_mid * 0.01 + final * d.F_final * 0.01));
    savefile(d);
}

/*** ---------------------------------------------------------- ***/

void removeScore() {
    char subjectID[10], semester[10], ID[10];
    printf("Subject ID: "); fflush(stdin); gets(subjectID);
    printf("Semester: "); fflush(stdin); gets(semester);
    printf("Student ID: "); fflush(stdin); gets(ID);

    data d = readfile(subjectID, semester);
    node n = searchNode(d.students, ID);
    removeNode(d.students, n);
    savefile(d);
}

void createScoreBoard() {
    data d;
    char ID[10], subname[20], lastname[20];
    int n_students;
    float mid, final;

    d.students = initLL();
    printf("Subject ID: "); fflush(stdin); gets(d.subjectID);
    printf("Subject Name: "); fflush(stdin); gets(d.subject);
    printf("Semester: "); fflush(stdin); gets(d.semester);
    printf("Percentage: "); scanf("%d %d", &d.F_mid, &d.F_final);
    printf("Number of students: "); scanf("%d", &n_students);
    for (int i = 0; i < n_students; ++i) {
        printf("-> Student %d:\n", i+1);
        printf("Student ID: "); fflush(stdin); gets(ID);
        printf("Subname: "); fflush(stdin); gets(subname);
        printf("Lastname: "); fflush(stdin); gets(lastname);
        printf("Mid term: "); scanf("%f", &mid);
        printf("Final term: "); scanf("%f", &final);
        addNode(d.students, ID, subname, lastname, mid, final, convert_score(mid * d.F_mid * 0.01 + final * d.F_final * 0.01));
    }
    savefile(d);
}