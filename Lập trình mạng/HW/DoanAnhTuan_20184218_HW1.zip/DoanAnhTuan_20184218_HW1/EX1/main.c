#include<stdio.h>
int main(){
  char a[4];
  int op;
  printf("Nhap ma HAZCHEM:");
  fgets(a,4,stdin);
  if(a[0]<'1'||a[0]>'4'){
    printf("khong phai ma HAZCHEM\n");
  }
  switch (a[1])
  {
  case 'S':
  case 's':
  case 'T':
  case 't':
  case 'Y':
  case 'y':
  case 'Z':
  case 'z':
    printf("Is the %c reverse coloured? (1.Yes/2.No)",a[1]);
    scanf("%d", &op); /* code */
    break;
  
  default:
    break;
  }
  switch (a[0])
  {
  case '1':
    printf("***Emergency action advice***\n");
        printf("Material:Jets\n");
    break;
  case '2':
    printf("***Emergency action advice***\n");

    printf("Material:Fog\n");
    break;
    /* code */
    break;
  case '3':
    printf("***Emergency action advice***\n");
    printf("Material:Foam\n");
    break;
    /* code */
    break;
  case '4':
    printf("***Emergency action advice***\n");
    printf("Material:Dry agent\n");
    break;
    /* code */
    break;

  default:
    break;
  }
  switch (a[1])
  {
  case 'P':
  case 'p':
    printf("Reactivity: can be violently reactive\n");
    printf("Protection: full protective clothing must be worn\n");
    printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    break;
  case 'R':
  case 'r':
    // printf("can be violently reactive\n") ;
    printf("Protection: full protective clothing must be worn\n");
    printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    break;
  case 'S':
  case 's':{
    
   
    if(op==1){
      printf("Reactivity: can be violently reactive\n");
      printf("Protection: protective gloves for fire only\n");
      printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    }
    else{
      printf("Reactivity: can be violently reactive\n");
      printf("Protection: breathing apparatus\n");
      printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    }
    }
     break;
  case 'T':
  case 't':
  {
    if (op == 1)
    {
      // printf("Reactivity: can be violently reactive\n");
      printf("Protection: protective gloves for fire only\n");
      printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    }
    else
    {
      // printf("Reactivity: can be violently reactive\n");
      printf("Protection: breathing apparatus\n");
      printf("Containment: the dangerous goods may be washed down to a drain with a large quantity of water\n");
    }
  }

    break;
  case 'W':
  case 'w':
    printf("Reactivity: can be violently reactive\n");
    printf("Protection: full protective clothing must be worn\n");
    printf("Containment: a need to avoid spillages from entering drains or water courses.\n");

        break;
  case 'X':
  case 'x':
    printf("Protection: full protective clothing must be worn\n");
    printf("Containment: a need to avoid spillages from entering drains or water courses.\n");

    break;
  case 'Y':
  case 'y':
    // printf("Reactivity: can be violently reactive\n");
    {
      if (op == 1)
      {
        printf("Reactivity: can be violently reactive\n");
        printf("Protection: protective gloves for fire only\n");
        printf("Containment: a need to avoid spillages from entering drains or water courses.\n");
      }
      else
      {
        printf("Reactivity: can be violently reactive\n");
        printf("Protection: breathing apparatus\n");
        printf("Containment: a need to avoid spillages from entering drains or water courses.\n");
      }
    }
    break;
  case 'Z':
  case 'z':
    // printf("Reactivity: can be violently reactive\n");
    {
      if (op == 1)
      {
        printf("Reactivity: can be violently reactive\n");
        printf("Protection: protective gloves for fire only\n");
        printf("Containment: a need to avoid spillages from entering drains or water courses.\n");
      }
      else
      {
        printf("Reactivity: can be violently reactive\n");
        printf("Protection: breathing apparatus\n");
        printf("Containment: a need to avoid spillages from entering drains or water courses.\n");
      }
    }
    break;

  default:
    break;
  }
  switch (a[2])
  {
  case 'E':
  case 'e':
    printf("Evacuation:consider evacuation\n");
    printf("*********************************\n");
    break;
  
  default:
    printf("*********************************\n");

    break;
  }
  return 0;
}