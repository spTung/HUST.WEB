#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<netdb.h>
#include<netinet/in.h>
#include<sys/socket.h>
#include<arpa/inet.h>

void ipTohostname(char*, struct in_addr);
void hostNametoip(char*);
int isIPV4Address(char*);

int main(int argc, char* argv[]){
    struct in_addr ip;    
    if(argc != 2){
        printf("Syntax is incorrect!");
        return 1;
    }
    
    if((isIPV4Address(argv[1]) != 3) && (isIPV4Address(argv[1]) != 1)){
        printf("Invalid address\n");
        exit(0);
    }

    if(!inet_pton(AF_INET,argv[1],&ip)){
        hostNametoip(argv[1]);
    } else {
        ipTohostname(argv[1], ip);
    }

    return 0;
}

void ipTohostname(char* para, struct in_addr ip){
    int i;
    struct hostent *hp;
    if((hp = gethostbyaddr(&ip,sizeof(ip), AF_INET)) == NULL){
        printf("Not found information\n");
    } 
    else {
        printf("Offical name: %s\n",hp->h_name);
        printf("Alias name:\n");
        for (i = 0; hp->h_aliases[i] != NULL; i++){
            printf("%s\n",hp->h_aliases[i]);
        }
    }
}

void hostNametoip(char* para){
    int i;
    struct hostent *he;
    struct in_addr **addr_list;
    if((he = gethostbyname(para)) == NULL){
        printf("Not found information\n");
    }
    else{
        addr_list = (struct in_addr **) he->h_addr_list;
        printf("Offical IP: %s\n",inet_ntoa(*addr_list[0]));
        printf("Alias IP:\n");
        for(i = 1; addr_list[i] != NULL; i++){
            printf("%s\n",inet_ntoa(*addr_list[i]));
        }
    }
    
}

int isIPV4Address(char* para){
    int i;
    char input[100];
    int count = 0;
    strcpy(input,para);
    for(i = 0; i < strlen(input); i++){
        if(input[i] == '.'){
            count++;
        }
    }
    return count;
}