#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFF_SIZE 1024

char *resolve_string(char buffer[], int len)
{
	int n = 0, m = 0, isError = 0;
	char number[BUFF_SIZE];
	char alpha[BUFF_SIZE];
	for (int i = 0; i < len - 1; i++)
	{
		char ch = buffer[i];
		if (ch >= '0' && ch <= '9')
		{ //number
			number[n] = ch;
			n++;
		}
		else if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
		{ //alphabet;
			alpha[m] = ch;
			m++;
		}
		else
		{
			isError = 1;
		}
	}
	number[n] = '\n';
	number[n + 1] = '\0';
	alpha[m] = '\0';

	if (isError == 1)
	{
		return "Error";
	}
	else
	{
		return strcat(number, alpha);
	}
}

int main(int argc, char *argv[])
{

	int sockfd, ret;
	struct sockaddr_in serverAddr;
	int newSocket;
	struct sockaddr_in newAddr;
	socklen_t addr_size;
	char buffer[BUFF_SIZE + 1];
	int bytes_received;

	if (argc != 2)
	{
		printf("Wrong number of parameters.\n");
		exit(EXIT_FAILURE);
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
	{
		printf("[-]Error in connection.\n");
		exit(1);
	}
	printf("[+]Server Socket is created.\n");

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(atoi(argv[1]));
	serverAddr.sin_addr.s_addr = htons(INADDR_ANY);

	ret = bind(sockfd, (struct sockaddr *)&serverAddr, sizeof(serverAddr));
	if (ret < 0)
	{
		printf("[-]Error in binding.\n");
		exit(1);
	}
	printf("[+]Bind to port %s\n", argv[1]);

	if (listen(sockfd, 10) == 0)
	{
		printf("[+]Listening....\n");
	}
	else
	{
		printf("[-]Error in binding.\n");
	}

	while (1)
	{
		newSocket = accept(sockfd, (struct sockaddr *)&newAddr, &addr_size);
		if (newSocket < 0)
		{
			exit(1);
		}
		printf("Connection accepted from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));
		while (1)
		{
			int result_len;
			bytes_received = recv(newSocket, buffer, BUFF_SIZE - 1, 0);
			if (bytes_received <= 0)
			{
				printf("Disconnected from %s:%d\n", inet_ntoa(newAddr.sin_addr), ntohs(newAddr.sin_port));
				break;
			}
			buffer[bytes_received] = '\0';
			printf("Receive: \"%s\" from client.\n", buffer);

			result_len = strlen(resolve_string(buffer, strlen(buffer)));
			send(newSocket, (const char *)resolve_string(buffer, strlen(buffer)), result_len, 0);
			printf("[+]Sent to client...\n");
		}
	}
close(newSocket);
return 0;
}
