#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

#define MAXLINE 4096 

void sendFile(char *_filepath, int sockfd)
{
    // Copy file path
    char filepath[MAXLINE];
    bzero(filepath, MAXLINE);
    strncpy(filepath, _filepath, strlen(_filepath)-1);

    // Open file
    FILE *file = fopen(filepath, "r");
    if (file == NULL)
    {
        printf("Error: File not found\n");
        return;
    }

    // Check file name
    char *temp = strtok(filepath, "/"), *filename = filepath;
    while (temp != NULL)
    {
        filename = temp;
        temp = strtok(NULL, "/");
    }

    // Send to server file name
    char buf[MAXLINE];
    int n;
    send(sockfd, filename, strlen(filename), 0);
    if (recv(sockfd, buf, MAXLINE, 0) == 0)
    {
        //error: server terminated prematurely
        printf("Error: File tranfering is interupted\n");
        return;
    }
    if (strcmp(buf, "Error: File is existent on server") == 0)
    {
        printf("Error: File is existent on server\n");
        return;
    }
    bzero(buf, MAXLINE);

    // Sen to server file size
    fseek(file, 0L, SEEK_END);
    long int size = ftell(file);
    sprintf(buf, "%ld", size);
    fseek(file, 0L, SEEK_SET); // Seek to the beginning of file
    send(sockfd, buf, sizeof(long), 0);
    bzero(buf, MAXLINE);

    if (recv(sockfd, buf, MAXLINE, 0) == 0)
    {
        //error: server terminated prematurely
        printf("Error: File tranfering is interupted\n");
        bzero(buf, MAXLINE);
        return;
    }
    if (strcmp(buf, "Error: File tranfering is interupted") == 0)
    {
        printf("Error: File tranfering is interupted\n");
        bzero(buf, MAXLINE);
        return;
    }

    // Send to server file content
    long int needtoreadcontent = size;
    while (needtoreadcontent > 0L)
    {
        if (needtoreadcontent < (long)MAXLINE)
        {
            n = fread(buf, 1, (int)needtoreadcontent, file);
            send(sockfd, buf, (int)needtoreadcontent, 0);
            bzero(buf, MAXLINE);
            n = recv(sockfd, buf, MAXLINE, 0);
            if (n <= 0)
            {
                //error: server terminated prematurely
                printf("Error: File tranfering is interupted\n");
                bzero(buf, MAXLINE);
                return;
            }
            needtoreadcontent = 0L;
        }
        else
        {
            n = fread(buf, 1, MAXLINE, file);
            send(sockfd, buf, MAXLINE, 0);
            bzero(buf, MAXLINE);
            n = recv(sockfd, buf, MAXLINE, 0);
            if (n <= 0)
            {
                printf("Error: File tranfering is interupted\n");
                return;
            }
            needtoreadcontent = needtoreadcontent - (long)MAXLINE;
        }
    }
    fclose(file);
    n = recv(sockfd, buf, 23, 0);
    if (n <= 0 || strcmp(buf, "Successful transfering") != 0)
    {
        //error: server terminated prematurely
        printf("Error: File tranfering is interupted\n");
        return;
    }
    else
    {
        printf("Successful transfering\n");
        return;
    }
}

int main(int argc, char **argv)
{
    int sockfd;
    struct sockaddr_in servaddr;
    char sendline[MAXLINE];

    if (argc != 3)
    {
        perror("Usage: TCPClient <IP address of the server");
        exit(1);
    }

    //Create a socket for the client
    //If sockfd<0 there was an error in the creation of the socket
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Problem in creating the socket");
        exit(2);
    }

    //Creation of the socket
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(argv[1]);
    servaddr.sin_port = htons(atoi(argv[2])); //convert to big-endian order

    //Connection of the client to the socket
    if (connect(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("Problem in connecting to the server");
        exit(3);
    }
    
    while (fgets(sendline, MAXLINE, stdin) != NULL)
    {
        sendFile(sendline, sockfd);
        fflush(stdin);
    }

    exit(0);
}
