#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define MAXLINE 4096               
#define LISTENQ 8                  
#define STORAGE "storage/"        

int main(int argc, char **argv)
{
    int n;
    int listenfd, connfd;
    socklen_t client_len;
    char buff[MAXLINE];
    struct sockaddr_in cliaddr, servaddr;

	//Step 1: Construct a TCP socket to listen connection request
    listenfd = socket(AF_INET, SOCK_STREAM, 0);

    //Step 2: Bind address to socket
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(atoi(argv[1]));

    bind(listenfd, (struct sockaddr *)&servaddr, sizeof(servaddr));

    listen(listenfd, LISTENQ);

    printf("%s\n", "Server started. Listening...\n");

    for (;;)
    {

        client_len = sizeof(cliaddr);
        connfd = accept(listenfd, (struct sockaddr *)&cliaddr, &client_len);
        printf("%s\n", "Received request...");

        while ((n = recv(connfd, buff, MAXLINE, 0)) > 0)
        {

            char filepath[MAXLINE];
            strcpy(filepath, STORAGE);
            filepath[33] = '\0';
            strcat(filepath, buff);
            filepath[33 + n] = '\0';

            if (fopen(filepath, "r") != NULL)
            {
                send(connfd, "Error: File is existent on server", 34, 0);
                puts("Error: File is existent on server");
            }
            else
            {
                // Sending file path
                printf("File path send to client: %s\n", filepath);
                send(connfd, filepath, strlen(filepath), 0);
                bzero(buff, MAXLINE);

                // Recieving file size
                long int size;
                if ((n = recv(connfd, buff, MAXLINE, 0)) > 0)
                {
                    size = atol(buff);
                    printf("File size: %ld\n", size);
                    send(connfd, buff, sizeof(long), 0);
                    bzero(buff, MAXLINE);
                }
                else
                {
                    printf("Error: File tranfering is interupted\n");
                    send(connfd, "Error: File tranfering is interupted", 37, 0);
                    bzero(buff, MAXLINE);
                    return 1;
                }

                // Create file
                FILE *file = fopen(filepath, "a");
                if (file == NULL)
                {
                    printf("Can't open file\n");
                    return 1;
                }

                long int needtowritecontent = size;
                while (needtowritecontent > 0L)
                {
                    if (needtowritecontent < (long)MAXLINE)
                    {
                        if ((n = recv(connfd, buff, (int)needtowritecontent, 0)) > 0)
                        {
                            send(connfd, buff, (int)needtowritecontent, 0);
                            fwrite(buff, 1, (int)needtowritecontent, file);
                            needtowritecontent = 0L;
                            bzero(buff, MAXLINE);
                            printf("Uploading file: %ld/%ld\n", (size - needtowritecontent), size);
                        }
                        else
                        {
                            printf("Error: File tranfering is interupted\n");
                            send(connfd, "Error: File tranfering is interupted", 37, 0);
                            bzero(buff, MAXLINE);
                            return 1;
                        }
                    }
                    else
                    {
                        if ((n = recv(connfd, buff, MAXLINE, 0)) > 0)
                        {
                            send(connfd, buff, MAXLINE, 0);
                            fwrite(buff, 1, MAXLINE, file);
                            needtowritecontent = needtowritecontent - (long)MAXLINE;
                            bzero(buff, MAXLINE);
                            printf("Uploading file: %ld/%ld\n", (size - needtowritecontent), size);
                        }
                        else
                        {
                            printf("Error: File tranfering is interupted\n");
                            send(connfd, "Error: File tranfering is interupted", 37, 0);
                            bzero(buff, MAXLINE);
                            return 1;
                        }
                    }
                }
                fclose(file);
                printf("Successful transfering\n");
                send(connfd, "Successful transfering", 23, 0);
                bzero(filepath, MAXLINE);
                bzero(buff, MAXLINE);
            }
        }

        if (n < 0)
        {
            perror("Read error");
            exit(1);
        }
        close(connfd);
    }
    close(listenfd);
}
