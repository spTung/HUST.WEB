#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BUFF_SIZE 1024
int main(int argc, char const *argv[])
{
    // valid number of argument
    if (argc != 3)
    {
        printf("Error parameter\n");
        exit(1);
    }
    int client_sockfd;
    int recvBytes, sendBytes;
    int n;
    struct sockaddr_in serv_addr;

    char buff[BUFF_SIZE];
    char sendline[BUFF_SIZE];
    char recvline[BUFF_SIZE + 1];

    // Construct socket
    client_sockfd = socket(AF_INET, SOCK_STREAM, 0);

    // Specify server address
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    serv_addr.sin_addr.s_addr = inet_addr(argv[1]);

    // Request to connect server
    if (connect(client_sockfd, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr)) < 0)
    {
        printf("\nError!Can not connect to sever! Client exit imediately! ");
        return 0;
    }
    while (1)
    {
        int i = 0, flag = 0;
        printf("please enter usename: ");
        scanf("%s", sendline);
        // printf("To Server: %s", sendline);
        send(client_sockfd, sendline, strlen(sendline), 0);
        n = recv(client_sockfd, recvline, BUFF_SIZE - 1, 0);
        recvline[n] = 0; //null terminate
        if (strcmp(recvline, "tkkhoa") == 0)
        {
            printf("user is not ready\n");
        }
        else if (strcmp(recvline, "khongtontai") == 0)
        {
            printf("user not exits\n");
        }
        else if (strcmp(recvline, "0") == 0)
        {
            do
            {
                printf("please enter passwork: ");
                scanf("%s", sendline);
                send(client_sockfd, sendline, strlen(sendline), 0);
                n = recv(client_sockfd, recvline, BUFF_SIZE - 1, 0);
                recvline[n] = 0; //null terminate
                if (strcmp(recvline, "thanhcong") == 0)
                {
                    printf("Login susscesfully \n");
                    printf("Press 'q' or 'Q' to logout: ");
                    scanf("%s", sendline);
                    if (strcmp(sendline,"q") ==0 || strcmp(sendline, "Q")==0)
                    {
                        printf("logout successfully");
                        exit(0);
                    }
                
                }
                else if (strcmp(recvline, "passsai") == 0)
                {
                    printf("passwork error\n");
                    i++;
                }
            } while (i < 2);
            if (i >= 5)
            {
                printf("user is block\n");
                return 0;
            }
        }
    }
}