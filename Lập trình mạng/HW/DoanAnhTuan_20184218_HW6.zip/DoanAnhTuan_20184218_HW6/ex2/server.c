#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BACKLOG 5
#define BUFF_SIZE 1024

#include <pthread.h>

typedef struct node
{
    char username[20];
    char password[20];
    int status;
    int log;
    struct node *next;
} node;

node *head = NULL;
void insert(char *, char *, int, int);
node *find(char *);
void openFile();
void *handle_connection(void *pclient);

    // seperate a string to 2 line: numbers and letters
int main(int argc, char *argv[])
{
    // valid number of argument
    if (argc != 2)
    {
        printf("error parameter\n");
        exit(1);
    }
    openFile();
    int listen_sockfd, conn_sockfd;
    int recvBytes, sendBytes;
    int n;

    struct sockaddr_in servaddr;
    struct sockaddr_in cliaddr;

    char data[BUFF_SIZE];
    char username[BUFF_SIZE];
    socklen_t sin_size;
    pid_t childpid;

    // Construct a TCP socket to listen connection request
    if ((listen_sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("\nError: ");
        return 0;
    }

    // Bind address to socket
    memset(&servaddr, '\0', sizeof servaddr);
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(atoi(argv[1]));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(listen_sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1)
    {
        perror("\nError: ");
        return 0;
    }

    // Listen request from client
    if (listen(listen_sockfd, BACKLOG) == -1)
    {
        perror("\nError: ");
        return 0;
    }

    printf("Server started!\n");

    // Communicate with client

    while (1)
    {
        sin_size = sizeof(struct sockaddr_in);
        if ((conn_sockfd = accept(listen_sockfd, (struct sockaddr *)&cliaddr, &sin_size)) == -1)
            perror("\nError: ");

        printf("Connecting Clinet ID: %s\n", inet_ntoa(cliaddr.sin_addr));
        pthread_t tid;
        int *pclient = malloc(sizeof(int));
        *pclient = conn_sockfd;
        pthread_create(&tid, NULL, handle_connection, pclient);
    }
   
    return 0;
}
void *handle_connection(void *pclient) //login
{
    int conn_sockfd = *((int*)pclient);
    int sockfd;
    char name[BUFF_SIZE], username[BUFF_SIZE];
    int n;

      while (1)
            {
                n = recv(conn_sockfd, username, BUFF_SIZE - 1, 0);
                username[n] = 0;
                printf("%s ", username);
                node *acc = find(username);
                if (acc != NULL)
                {
                    if (acc->status == 1)
                    {

                        send(conn_sockfd, "0", 1, 0);
                        int i = 0;
                        while (i < 2)
                        {
                            n = recv(conn_sockfd, username, BUFF_SIZE - 1, 0);
                            username[n] = 0;
                            if (strcmp(acc->password, username) == 0)
                            {
                                send(conn_sockfd, "thanhcong", 20, 0);
                                printf("login successfully\n");
                                return 0;
                                
                            }
                            else
                            {
                                send(conn_sockfd, "passsai", strlen("passsai"), 0);
                                acc->log++;
                                writeFile();
                                i++;
                            }
                            if (acc->log >= 5)
                            {
                                acc->status = 0;
                                writeFile();
                            }
                        }
                    }
                    else if (acc->status == 0) //tai khoan khong hoat dong
                    {

                        send(conn_sockfd, "tkkhoa", strlen("tkkhoa"), 0);
                        printf("user is block\n");
                    }
                }
                else
                {
                    send(conn_sockfd, "khongtontai", strlen("khongtontai"), 0);
                    printf("user not exits\n");
                }
            }
            
            
            close(sockfd);
            free(pclient);
}
void insert(char username[20], char password[20], int status, int log)
    {
        node *temp;
        temp = (node *)malloc(sizeof(node));
        strcpy(temp->username, username);
        strcpy(temp->password, password);
        temp->status = status;
        temp->log = log;
        temp->next = head;
        head = temp;
    }

    node *find(char name[20])
    {

        node *current = head;

        if (head == NULL)
        {
            return NULL;
        }
        int i = 0;

        while (strcmp(current->username, name) != 0)
        {
            if (current->next == NULL)
            {
                return NULL;
            }
            else
            {
                current = current->next;
            }
        }
        return current;
    }

    void openFile()
    {
        node *acc;
        char *username;
        char *password;
        int status;
        int log;
        char c;
        // int u = 0, p = 0, blank = 0;
        username = (char *)malloc(20);
        password = (char *)malloc(20);
        FILE *f;
        if ((f = fopen("account.txt", "r+")) == NULL)
        {
            printf("Khong tim thay %s\n", "acount.txt");
            return;
        }
        while (1)
        {
            fscanf(f, "%s", username);
            fscanf(f, "%s", password);
            fscanf(f, "%d", &status);
            fscanf(f, "%d", &log);
            if (feof(f))
                break;

            insert(username, password, status, log);
        }

        free(username);
        free(password);
        fclose(f);
    }
    void writeFile()
    {
        FILE *f;
        node *temp;
        temp = head;
        f = fopen("account.txt", "w+");
        while (temp)
        {
            fprintf(f, "%s %s %d %d", temp->username, temp->password, temp->status, temp->log);
            fprintf(f, "\n");
            temp = temp->next;
        }
        fclose(f);
    }